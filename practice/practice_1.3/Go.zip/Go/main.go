/*
Copyright © 2024 NAME HERE <EMAIL ADDRESS>
*/
package main

import "pr3/cmd"

func main() {
	cmd.Execute()
}
